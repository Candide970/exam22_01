from pyspark.sql import SparkSession
from pyspark.sql.functions import col, split, expr
from pyspark.ml.feature import VectorAssembler, StringIndexer
from pyspark.ml.classification import DecisionTreeClassifier
from pyspark.ml.evaluation import MulticlassClassificationEvaluator

# 1. Configuration de la session Spark
minio_ip = "172.20.0.2"

spark = SparkSession.builder \
    .appName("Examen_Final_Cyber_Sec") \
    .config("spark.hadoop.fs.s3a.endpoint", f"http://{minio_ip}:9000") \
    .config("spark.hadoop.fs.s3a.access.key", "minioadmin") \
    .config("spark.hadoop.fs.s3a.secret.key", "minioadmin") \
    .config("spark.hadoop.fs.s3a.path.style.access", "true") \
    .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem") \
    .config("spark.driver.host", "127.0.0.1") \
    .getOrCreate()

spark.sparkContext.setLogLevel("ERROR")

# Fonction technique pour convertir une IP 
def ip_to_long(ip_col):
    parts = split(ip_col, "\.")
    return (parts.getItem(0).cast("long") * 16777216 +
            parts.getItem(1).cast("long") * 65536 +
            parts.getItem(2).cast("long") * 256 +
            parts.getItem(3).cast("long"))

try:
    print("\n DÉMARRAGE DU PIPELINE DE NETTOYAGE ...")

    # 2. Chargement et Nettoyage des Logs
    logs_df = spark.read.csv("s3a://exam-bucket/logs/Network_logs.csv", header=True, inferSchema=True)
    logs_df = logs_df.withColumn("ip_numeric", ip_to_long(col("Source_IP")))

    # 3. Chargement et Préparation de la base Geo-IP
    geo_df = spark.read.csv("s3a://exam-bucket/dbip/dbip-country-lite-2026-01.csv") \
        .toDF("ip_start_str", "ip_end_str", "country_name")
    
    geo_df = geo_df.withColumn("start_num", ip_to_long(col("ip_start_str"))) \
                    .withColumn("end_num", ip_to_long(col("ip_end_str")))

    # 4. Jointure  pour obtenir les pays
    print(" Jointure avec la base des pays...")
    final_df = logs_df.join(geo_df, (logs_df.ip_numeric >= geo_df.start_num) & (logs_df.ip_numeric <= geo_df.end_num), "left")

    # 5. Indexation des variables qualitatives (Pays et Intrusion)
    country_indexer = StringIndexer(inputCol="country_name", outputCol="country_index", handleInvalid="skip")
    final_df = country_indexer.fit(final_df).transform(final_df)

    label_indexer = StringIndexer(inputCol="Intrusion", outputCol="labelIndex", handleInvalid="skip")
    data_indexed = label_indexer.fit(final_df).transform(final_df)

    # 6. Assemblage des variables (Features)
    feature_cols = ["Port", "Payload_Size", "country_index"]
    assembler = VectorAssembler(inputCols=feature_cols, outputCol="features", handleInvalid="skip")
    data_ml = assembler.transform(data_indexed)

    # 7. Entraînement du modèle
    print(" Apprentissage du modèle ...")
    (train_data, test_data) = data_ml.randomSplit([0.8, 0.2], seed=42)
    dt = DecisionTreeClassifier(labelCol="labelIndex", featuresCol="features")
    model = dt.fit(train_data)

    # 8. Prédictions et Évaluation
    predictions = model.transform(test_data)

    print("\n" + "="*50)
    print(" APERÇU DES PRÉDICTIONS")
    print("="*50)
    predictions.select("Source_IP", "country_name", "Intrusion", "prediction").show(100)

    # 9. Calcul de la précision (Accuracy)
    evaluator = MulticlassClassificationEvaluator(labelCol="labelIndex", predictionCol="prediction", metricName="accuracy")
    accuracy = evaluator.evaluate(predictions)
    print(f" PRÉCISION GLOBALE DU MODÈLE : {accuracy * 100:.2f}%")
    print("="*50)

    #  EXPORT POUR POWER BI ---
    print("\n EXPORTATION DES RÉSULTATS POUR POWER BI...")
    
    
    # 'prediction' est le résultat de l'IA (0 ou 1)
    bi_df = predictions.select(
        "Source_IP", 
        "country_name", 
        "Port", 
        "Payload_Size", 
        "Intrusion", 
        "prediction"
    )

    # coalesce(1) crée UN SEUL fichier CSV
    # overwrite écrase l'ancien export à chaque lancement
    bi_df.coalesce(1).write.mode("overwrite").option("header", "true").csv("/opt/spark/work-dir/resultats_ia_bi")
    
    print(" Export terminé ! Retrouvez le dossier 'resultats_ia_bi' sur votre PC.")
    print("="*50)

except Exception as e:
    print(f"\n ERREUR DURANT L'EXÉCUTION : {e}")

finally:
    print("\n Arrêt de la session Spark.")
    spark.stop()